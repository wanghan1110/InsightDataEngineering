# bash spawn_kafka_streams.sh localhost 120 k1
bash spawn_kafka_streams.sh 34.211.247.230 120 k1
# bash spawn_kafka_streams.sh 52.10.138.212 120 k2
# bash spawn_kafka_streams.sh 35.167.89.94 120 k3
# bash spawn_kafka_streams.sh 35.160.69.184 120 k4

# kill the process
# tmux kill-session -t k1