# kill the process
tmux kill-session -t k1
# tmux kill-session -t k2
# tmux kill-session -t k3
# tmux kill-session -t k4